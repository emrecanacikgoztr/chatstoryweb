# ChatStory — Türkçe Stil Kılavuzu

**VERSION:** v0.4 — Bölüm 1 pass 3 sonrası
**LAST UPDATED:** 2026-04-21
**HOW TO USE:** Yeni bölüm yazımında bu dosyayı Claude'a ver. Her düzenlemeden
sonra ilgili bölümü güncelle.

---

## GENEL PRENSİPLER

_Bu bölüm bütün karakterler ve sahneler için geçerli._

### Dil registeri
- WhatsApp grup sohbeti, edebi Türkçe değil
- Millennial 29 yaş kesimi, Gen Z taklidi değil
- Kafa akışı: bir düşünce = bir mesaj, paragraf yok
- Türkçe + ara sıra İngilizce kelime (kimlerde geçerli, karaktere göre)

### Mesaj ritmi
- Düşünce akışı: bir düşünce = bir mesaj
- Karakterler düşünürken yazar, yazarken düzeltir
- Birbirini kesmek doğal: Lena konuşurken Zoe "dur marc yazdı" diyebilir

### Mekan ve ilişki mantığı (KURAL — pass 3)
**Karakterler arasındaki gerçek yaşam ilişkisi, mesaj mantığını belirler.**

Zoe ve Marc birlikte yaşıyor. Bu şunları etkiler:
- ❌ Zoe ve Marc **aynı evdeyken** WhatsApp'tan uzun sohbet etmezler (absürt durur)
- ❌ Sahne E ilk versiyonunda Marc-Zoe screenshot'u vardı — kaldırıldı, Zoe sözlü anlattı
- ✅ Zoe Marc ile **yüz yüze** konuşmayı Lena ve YOU'ya **anlatır**
- ✅ Marc Zoe'ye mesaj atarsa: **ikisi ayrı yerdeyken** (iş, seyahat, toplantı) mantıklı

**Diğer ilişki mantıkları:**
- Zoe & Lena: Best friend, her an yazışır (grup veya DM)
- Zoe & YOU, Lena & YOU: Grup üyesi; DM'e geçiş drama anı için saklanır
- Alex, Lena: Yeni ilişki, yazışma uzun ve seçili

### Gereksiz kelimeler (KURAL — pass 3)
**Vurgu için kullanılan ama anlam eklemeyen kelimeler atılacak.**

- ❌ "sadece içim rahat etsin diye" → ✅ "için rahat etsin diye"
- ❌ "suçlu hissettim şimdi bile" → ✅ "suçlu hissettim şimdi"
- ❌ "aslında çok çok tatlı" → ✅ "çok tatlı"

**Tetikleyici kelimeler:** "sadece", "bile", "aslında", "çok çok", "gerçekten", "kesinlikle"
**Kontrol sorusu:** Bu kelimeyi silsem anlam değişir mi? → Hayır ise, sil.

### Evrensel yasak listesi
- Kitap Türkçesi (stilize cümleler, edebi ifadeler)
- Zoomer taklidi aşırı ifadeler (sürekli "aq", "ya abi", "valla")
- Gereksiz vurgu kelimeleri (yukarıdaki liste)

---

## KARAKTER: ZOE

### Yazım default'ları
- Küçük harf default
- Noktalama yok (nokta hiç, virgül nadir/kaza)
- Bir düşünceyi 2-4 mesaja böler

### Sadelik ve doğru Türkçe (pass 1 gözlem)

**Gözlem (henüz kural değil, 3 örneklik pattern):** Zoe'nin dilinde **zorlama stilize ifadeler** Zoe'ye uymuyor. "Fazla uzun buldum" gibi yarı-analitik, "+ hiç" gibi poetik-kısa, "spor yapıcam" gibi uydurma çekim — bunlar yanlış yöne kayış.

Zoe **şapşal ama dürüst** Türkçe konuşur. Üstüne stil biniyorsa, Zoe değil, "Zoe'yi yazan yazar" duyuluyor.

**Pass 1 düzeltmeleri:**
- ❌ "asansörün dördüncü kata çıkmasını fazla uzun buldum" → ✅ "asansörün dördüncü kata çıkmasını beklerken yoruldum"
- ❌ "yorgan + çay + hiç" → ✅ "yorgan + çay"
- ❌ "yarından itibaren spor yapıcam bu arada" → ✅ "yarından itibaren spora başlıyorum"

**Çıkarım:** Bir Zoe cümlesini yazarken test sorusu — **"normal bir insan WhatsApp'ta böyle yazar mı?"** Stilize edilmiş geliyorsa, sadeleştir.

### İkonik hatalar (bilinçli, karakter işareti)
- _[henüz netleşmedi — "yanı", "bi şey" gibi hatalar Bölüm 1'de ben yazmış olsam da sen onaylamadın, pass 1'de görmüyoruz]_
- **Çalıştığı onaylanan:** "HSDGSDG" tipi klavye yumruklama (mizah/şaşkınlık), "sorucam" (yapıcak yerine), "kapatıcam" (kapatacağım yerine)

### İngilizce kullanımı (KURAL — pass 3)
**Zoe için: hiç İngilizce kelime yok.**
- ❌ "belki yorgundur idk" → ✅ "belki yorgundur bilmiyorum"
- Zoe tamamen Türkçe konuşur. İngilizce düşecekse Lena atabilir (nadiren).

### Emoji kullanımı
- Kullandığı tespit edilen: 🥹 😭 🙂 🙏 🫠 🧡
- Çeşit az, tekrarlı
- Kalp emoji (❤️ 💕 💖) yok — 🧡 tek kalp renk

### BÜYÜK HARF kullanımı
- Şok/panik/heyecan: "NE", "LENA KİM BU", "YOK ARTIK"
- Yalnız ses yükseltme, asla vurgulama için kullanmaz

### Özel ifadeler
- _[henüz belirsiz — "haha" ile başlayan mesaj kuralı brifingdeydi ama pass 1'de denenmedi]_

### Zoe için YANLIŞ/DOĞRU örnek çiftleri

**Örnek #1 — Stilize cümle sadeleştirmesi**
- ❌ YANLIŞ: "ben bugün asansörün dördüncü kata çıkmasını fazla uzun buldum"
- ✅ DOĞRU: "ben bugün asansörün dördüncü kata çıkmasını beklerken yoruldum"
- **Neden:** "Fazla uzun buldum" analitik, Lena'ya yakışır. Zoe direkt "yoruldum" der.

**Örnek #2 — Poetik sıkıştırma yerine sade liste**
- ❌ YANLIŞ: "yorgan + çay + hiç"
- ✅ DOĞRU: "yorgan + çay"
- **Neden:** "+ hiç" stil katıyor, Zoe hayatı özetlemeye çalışıyor gibi. Sade liste gerçek.

**Örnek #3 — Uydurma çekim yerine doğal Türkçe**
- ❌ YANLIŞ: "yarından itibaren spor yapıcam bu arada"
- ✅ DOĞRU: "yarından itibaren spora başlıyorum"
- **Neden:** "Spor yapıcam" çocukça çekim, "bu arada" akışa zorla takıntı. "Spora başlıyorum" hem doğru hem Zoe.

---

## KARAKTER: LENA

### Yazım default'ları
- Düzgün yazım, virgül var, nokta ara sıra
- Küçük harf default (özel isim büyük)
- Tam cümle yazabilir ama her zaman değil

### Avukat esprisi kuralı (pass 1 öğrenim)

**KURAL:** Lena **hukuki terim tabanlı espri yapmaz.** "Delil", "mahkeme", "hüküm", "müvekkil" gibi kelimeler Lena'nın ağzına *kitap* gibi oturuyor — espri yaratmak yerine kurmaca hissi veriyor.

Eğer espri olacaksa, **hukuki düşünce tarzı** olabilir (argüman kurma, kanıt isteme, mantık hatası yakalama) ama **hukuki kelime değil.**

**Pass 1 örneği:**
- ❌ YANLIŞ: Lena: "delil mahkemede" (Zoe'nin spor ertelemesine)
- ✅ DOĞRU: Lena: "hadi ama" (basit, direkt, Lena ses'i)

**Çıkarım:** Avukat karakterinin ağzına her sahnede espri koymaya çalışmamak. Lena'nın avukatlığı bir **karakter detayı**, espri zemini değil. Karakter bible'da "avukat esprisi" yazıyor olsa bile, her bölüme sıkıştırma zorunluluğu yok.

### İngilizce kullanımı
- _[henüz pass 1'de denenmedi — Bölüm 1 eski versiyonunda "we should find whose lipstick" gibi cümleler vardı, kalmış/kalmamış kontrol edilecek]_

### Emoji kullanımı
- Pass 1'de gözüken: 🥹 😅 🫠
- Minimal — bir cümleye bir emoji max

### "Kontrol kaybı" durumu
- Heyecanlanınca Zoe'ye yaklaşan yazım ("LENAAAA" tipi uzun sesli) — ama bu Zoe'nin Lena'ya yazımı, Lena'nın kendi ses'i değil
- Lena'nın kendi kontrol kaybı henüz Bölüm 1'de net değil — Bölüm 2+'da gözlenecek

### Lena için YANLIŞ/DOĞRU örnek çiftleri

**Örnek #1 — Zorlama avukat esprisi yerine basit tepki**
- ❌ YANLIŞ: "delil mahkemede"
- ✅ DOĞRU: "hadi ama"
- **Neden:** Hukuki terim Lena'nın mizahı yerine mesleğini ön plana çıkarır. "Hadi ama" hem samimi hem Zoe'ye özgü bir itiraz — Lena'nın gerçek ses'i.

---

## KARAKTER: YOU (Oyuncu)

### Nötr ses prensibi
- Baskın özelliği YOKTUR
- İçerik değişken, ses sabit

### Yasak liste
- Küfür/argo yok ("aq", "ya abi", "valla")
- Emoji 0 ya da nadir 1
- Abartı yok ("çok çok", "müthiş", "aşırı")
- İmzalı kelime yok (tekrar eden iz)
- İngilizce kelime yok (saf Türkçe)
- Şaka baskın olmaz
- Dayatma yok, öneri var

### Seçim formatı
- Yorum formatı, soru değil (sonu "?" olmayacak)
- Karakterlere eşit mesafe
- Nötr ≠ kararsız

### YOU için YANLIŞ/DOĞRU örnek çiftleri

**Örnek #1:**
- ❌ YANLIŞ:
- ✅ DOĞRU:
- **Neden:**

---

## KARAKTER: MARC (Screenshot)

### Yazım default'ları
- Tam cümle, büyük harfle başlar, noktalama tam
- Emoji yok
- "Tatlım", "aşkım" yok — ismi veya isimsiz
- Kısa, hesaplı, savunmaya geçince "neden sordun ki" tipi dönüşler

### Marc için örnek çiftleri

**Örnek #1:**
- ❌ YANLIŞ:
- ✅ DOĞRU:

---

## KARAKTER: ALEX

_[Bölüm 3 veya 4'te derinleşecek — şu an minimum profil]_

### Başlangıç notları
- Yaratıcı sektör dili
- Siyah kalp emoji (🖤) kullanır
- İlginç kelime seçimleri ("fenomen", "seni okumak güzel")
- Cevap süresi tutarsız — charm tool

---

## KARAKTER: SARA

_[Bölüm 4+ geliştirilecek — minimum profil]_

### Başlangıç notları
- Sadece screenshot'larda
- Kısa, mesafeli, tam cümle
- Emoji yok

---

## SAHNE BAZLI PRENSIPLER

### Açılış sahneleri
- Günlük doku ile başla (spor, ev, iş şikayeti) — direkt drama değil
- Foto ile karakter tanıtımı (Lena gym selfie, Zoe cozy selfie)
- İlk seçim dokuyu kurar (kişilik), drama seçimi sonra gelir

### Dramatik reveal anları
- Foto/ipucu **kaçırılabilir** şekilde sunulur (oyuncu dikkat edip görür)
- Önce **kaçırma reaksiyonu** ("adam ölmüş çalışmaktan"), sonra **fark etme** (YOU seçimi)
- Reveal sonrası **sessizlik** — silence block şok anını büyütür

### Caption stratejisi (KURAL — pass 3)
**Fotoğraf caption'ları mesajın tekrarı değil, fotoğrafın "sesli düşünce"si olmalı.**

- ❌ Önce mesaj "foto da attı" → sonra foto caption "foto attım"  (çiftleme)
- ✅ Mesaj silinir, caption direkt konuşur: "foto attııı 🥹"

**Prensip:** Foto zaten bir eylem, caption eylem **anlatma** yerine **dramatize** eder.
- Zoe caption: duygu + emoji ("Gururlu hehee", "foto attııı 🥹", "benim gecem 🥹")
- Lena caption: sade, hafif meydan okuma ("ne dersinizz??")
- Marc caption: yok (screenshot'larda caption kullanılmaz)

### DM geçişleri
- Grup → DM: karakterin yalnız hissettiği, diğerlerinin uyuduğu anlarda
- Zoe DM'i "uyanık mısın" ile açar, önce açıklama sonra itiraf
- Header rengi kanala göre değişir (engine destekliyor)

### Cliffhanger kuralları
- Açık iletişim prensibi — "bak" tek kelimelik cliffhanger yok
- Bir cümle olmalı, ne gördüğünü/düşündüğünü söylemeli
- Sessizlikle kapatmak ("ekran kararır. gece biter.") OK

---

## SEÇİM NOKTASI TASARIMI

### Format kuralları
- Yorum formatı, soru değil
- Her seçim karakterden bir tepki tetikler (dekoratif değil)
- İki seçenek gerçekten farklı yöne götürsün
- **Kısa metin (KURAL — pass 3):** Seçim metinleri mobile ekranda tek satıra sığsın. İdeal 5-9 kelime. 10+ kelime uzun.
  - ❌ "iki yılda tanıdığın biri hakkında bir fotoğraf üstüne fikir değiştirme" (9 kelime — uçta)
  - ❌ "çok tatlı ama zoe, şu ara neden bu kadar tatlı sence, bir şey olduğu için olabilir mi" (17 kelime — çok uzun)
  - ✅ "bazen en iyisi yorgan ve çay" (6 kelime)
  - ✅ "uyu biraz, yarın lena ile beraber konuşun" (7 kelime)

### Reply zinciri tasarımı (pass 1 öğrenim — KURAL)

**KURAL:** YOU seçimi bir **pozisyon** alıyorsa, reply'lar o pozisyonu **doğru okumalı.** Yani Zoe ve Lena YOU'nun ne söylediğini **yanlış anlarsa**, sahne yapay hissediyor.

**Üç tipoloji:**

1. **YOU bir tarafa meyletti** (örn: "Lena haklı, Zoe tarih koy")
   - Destek aldığı taraf YOU'yla ittifak hisseder
   - Sıkıştırılan taraf direnç gösterir veya teslim olur
   - Örnek: A replies — Lena memnun, Zoe tarih vermeye çalışır

2. **YOU hakem pozisyonunda** (örn: "İkiniz de abartıyorsunuz")
   - Hiç kimsenin tarafını tutmadı, dengeledi
   - **İki karakter de YOU'ya dönmeli**, birbirine değil
   - Sahne tartışmayı **kapatır**, kimse kazanmaz/kaybetmez
   - Örnek: B replies — Zoe Lena'yı çağırır, Lena çekilir, konu kapanır

3. **YOU tavır değiştirdi** (sahne içi ileri seçimlerde)
   - Önceki ton'a göre zıt yön seçtiyse, karakterler sürpriz/fark edebilir
   - "Sen az önce şöyle demiştin" tipi meta-farkındalık OK

**YANLIŞ pattern örneği (pass 1'de düzeltilen):**

YOU B seçimi: "ikiniz de abartıyorsunuz, ikisi de hayat"
- ❌ Zoe: "çok güzel söyledin / bunu oturduğum yerden tekrarlıyorum"
- ❌ Lena: "zoe sen kaybetmedin / ama kazandın da diyemem"
- **Sorun:** YOU hakem pozisyonunda, ama Zoe "benim tarafımı tuttun" gibi okuyor (tembelliğine kılıf çıkardı), Lena "tartışma bitti, hüküm verildi" gibi okuyor. İkisi de YOU'yu yanlış anlamış.

**DOĞRU pattern (düzeltilmiş):**
- ✅ Zoe: "haklısın ya / lena duydun mu"
- ✅ Lena: "duydum / tamam ben çekildim"
- **Neden:** Zoe hakem-YOU'yu doğru okuyor (anlıyor ama şaka yollu Lena'ya sesleniyor), Lena da "tamam kapatıyorum" diyor. Kimse kazanmadı, tartışma doğal bitti.

### Tepki zinciri
- 3-6 mesaj ideal
- Karakterler arası yazışmayla bitmeli (birbirine dönmek, sahneye geri akış)
- Son mesaj sahneyi **kilitlemeli** veya **sonraki konuya zemin hazırlamalı**

---

## DEĞİŞİKLİK LOG'U

_[Her major güncelleme burada]_

### v0.4 (2026-04-21) — Bölüm 1 pass 3
- **Mekan ve ilişki mantığı KURALI:** Aynı evde yaşayan karakterler uzun
  WhatsApp sohbeti yapmaz. Sahne E'deki Marc-Zoe screenshot'u kaldırıldı,
  Zoe sözlü anlatım yapıyor.
- **Gereksiz kelimeler KURALI:** "Sadece", "bile", "aslında", "çok çok"
  gibi vurgu kelimeleri anlam eklemiyorsa atılır.
- **Caption stratejisi KURALI:** Foto caption'ı mesajın tekrarı değil,
  fotoğrafın sesli düşüncesi. Mesaj + caption çiftleme yok.
- **Zoe için İngilizce yasağı:** "idk" gibi kısaltmalar bile çıkar.
- **Kısa seçim metni KURALI:** Seçimler 5-9 kelime ideal, 10+ uzun.
- **6 direkt düzeltme** script'te (leg day → bacak günü, suçlu hissettim
  şimdi bile → şimdi, vs).
- **8 yapısal değişiklik:** Lena caption, Seçim 1 B metni + reply zinciri,
  twocups caption, Marc screenshot, Seçim 5 A, Alex caption, YOK ARTIK
  silindi, masanda kimin rujuyla... silindi.

### v0.3 (2026-04-21) — Bölüm 1 pass 2
- **Reply zinciri kuralı eklendi:** YOU'nun seçim pozisyonu (taraflı,
  hakem, tavır değiştirme) reply'lardan doğru okunmalı.
- Bölüm 1 Seçim #1 B opsiyonunun reply'ları düzeltildi (Zoe ve Lena
  YOU'yu yanlış okuyordu, hakem pozisyonunu "tembellik onayı" olarak
  yorumluyorlardı).

### v0.2 (2026-04-21) — Bölüm 1 pass 1
- **Zoe için sadelik gözlemi:** 3 örnekte stilize cümleler sadeleştirildi.
  Pattern öneriyor: Zoe'ye zorlama stil koyma, doğru Türkçe + doğal akış.
- **Lena için avukat esprisi kısıtı:** "Delil mahkemede" çıkarıldı.
  Kural: hukuki terim-tabanlı espri yok. Espri varsa düşünce-tarzı,
  kelime değil.
- **Gözlem:** Bu pass dar kapsamlı (sadece 4 değişiklik) — daha derin
  pattern'ler gelecek pass'lerde ortaya çıkacak.

### v0.1 (2026-04-21)
- İskelet kuruldu, boş şablon

---

## NOTLAR VE UYARILAR

_[Claude'a özel uyarılar, "sakın bunu yapma" notları]_
