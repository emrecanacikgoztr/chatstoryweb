# ChatStory — Sezon Notları

**VERSION:** v0.6 — Bölüm 2 final + genel pass
**LAST UPDATED:** 2026-04-22
**HOW TO USE:** Bu dosya sezonun master referansıdır. Bölüm yazarken, ipucu planlarken, süreklilik kontrol ederken buraya bak. Stil kılavuzu ayrı: `turkish_style_guide.md`.

> **Rebuild notu:** Orijinal `episode_notes.md` önceki chat çökünce kayboldu. Bu dosya geçmiş chat'lerden toplandı. Eksik/belirsiz yerler `[?]` ile işaretli — sen onaylarsan kesinleştireceğim.

---

## NEDİR BU OYUN

WhatsApp-style mobil narrative oyunu. Oyuncu **YOU** — Zoe ve Lena'nın grup sohbetinde üçüncü, sessiz kişi. YOU sadece seçim anlarında konuşur; seçimler yorum formatında, soru değil.

Hikaye: sadakatsizlik, dostluk ve "görmek istemediğimiz şeyler" üstüne.

15 bölümden **14 bölüme** düşürüldü (Bölüm 1 yazılırken eski B1 ve B2'nin içeriği tek bölüme sığdı).

---

## KARAKTERLER

**Zoe (29, marketing)** — Duygusal merkez. Sıcak, biraz beceriksiz. Aptal olduğu için değil, **bakmak istemediği için** körleşiyor. Marc'ın sevgilisi, birlikte yaşıyorlar. **En büyük korkusu: haklı çıkmak.**

**Lena (28, avukat)** — Yarı Koreli yarı beyaz, uzun, her zaman kontrollü. Zoe'nin en iyi arkadaşı. **Ayna dinamiği:** Zoe hiç kontrol sahibi olmadı, Lena hep kontrole çalıştı — ikisi de aynı yere geliyor. **En büyük korkusu: kontrolü kaybetmek.**

**YOU (oyuncu)** — Sessiz gözlemci. Sadece seçim noktalarında konuşur. Seçimler yorum/tepki formatında, soru değil.

**Marc (35, finance)** — **Asla direkt mesaj atmaz.** Sadece Zoe'nin paylaştığı screenshot'larda görünür. Stratejik, karizmatik, zayıf. Zoe'yi seviyor ama kendini durduramıyor. **En büyük korkusu: gerçek yüzünün görülmesi.**

**Alex (32, creative director, Latino)** — Lena'nın yeni ilgisi. Karizmatik, player, herkese özel hissettirir. Farkında olmadan Sara'ya köprü oluyor. Marc'ı **Sara üzerinden tanıyor** (Sara Alex'in eski girl best friend, Marc'ın iş arkadaşı). Doğrudan iş ilişkisi yok.

**Sara (28, finance, Marc'ın iş arkadaşı)** — Sarışın, şık, Zoe'nin tam tersi. Marc'la ilişkide. **Aktif olarak ipucu bırakıyor** — Zoe'nin çekilmesini istiyor. Alex'in eski girl best friend'i. YOU'yu Alex üzerinden bulur.

---

## DALGA RİTMİ

Her bölümün duygusal yönü var: ↑ yukarı (rahatlama, Marc tatlı), ↓ aşağı (şüphe, yeni ipucu), — düz (geçiş), ⚡ kriz.

Temel döngü: **şüphe → Marc tatlı davranır → Zoe yumuşar → yeni ipucu → şüphe...**

İki yanlış alarm ritmi kırar.

---

## 14 BÖLÜM HARİTASI

| # | Başlık | Dalga | Durum |
|---|--------|-------|-------|
| 1 | O Sadece Meşgul | ↓ | ✅ Pass 3 bitti |
| 2 | Date | ↑ | 📝 Script v1 var (txt, stil pass henüz yok) |
| 3 | Sara | ↓ | 📝 Yapı var (eski B4) |
| 4 | Çok Tatlı | ↑ | 📝 Yapı var (eski B5) — **küçük yanlış alarm** |
| 5 | Fotoğraf | ↓ | 📝 Yapı var (eski B6) |
| 6 | İş Seyahati | ↓ | 📝 Yapı var (eski B7) |
| 7 | Dönüş | ↑ | 🔲 Çerçeve yok (eski B8) |
| 8 | Lena'nın Sorusu | ↓ | 🔲 Çerçeve yok (eski B9) — **büyük yanlış alarm başlangıç** |
| 9 | Her Şey Yolunda | ↑ | 🔲 Çerçeve yok (eski B10) — **büyük yanlış alarm "geçer"** |
| 10 | Ekran Görüntüsü | ↓ | 🔲 Çerçeve yok (eski B11) |
| 11 | Sara'nın DM'i | — | 🔲 Çerçeve yok (eski B12) |
| 12 | Sorma Bana | ⚡ | 🔲 Çerçeve yok (eski B13) — dallanma noktası |
| 13 | Son İpucu | ↓ | 🔲 İki versiyon 13A/13B (eski B14) |
| 14 | Biliyordum | END | 🔲 Tek final (eski B15) |

---

## BÖLÜM ÖZETLERİ

### BÖLÜM 1 — "O Sadece Meşgul" ✅

**Durum:** Script tamamlandı, 3 pass düzenlendi, test edildi.

Açılış spor/ev dokusu. Lena bacak günü selfie'si, Zoe cozy selfie. Marc 2-3 haftadır soğuk. Zoe'nin sorgulaması. Marc "iki fincan + ruj izi" fotoğrafı. Zoe ertesi gece Marc'a soruyor — Marc "neden sordun ki" diyerek savunmaya geçiyor. Lena Alex'i reveal ediyor. Zoe geceyarısı DM'ye geçip YOU'ya saat hediyesi + iş seyahati şüphesini itiraf ediyor.

**Bu bölümde yerleşen şeyler:**
- Marc şüphesinin başlangıcı (ruj izi, ilk)
- "neden sordun ki" — Marc'ın savunmacı eğilimi
- Zoe'nin "şu ara çok tatlı" gözlemi (wave rhythm'ın kuruluşu)
- Alex'in Lena'nın hayatına girişi (reklam ajansı CD, ortak arkadaş üzerinden)
- Saat hediyesi + 3 günlük yurtdışı iş seyahati ("management meeting for the weekend")
- Zoe-YOU DM kanalının açılması

### BÖLÜM 2 — "Date" 📝

**Dalga:** ↑ YUKARI (Marc tatlı, Lena heyecanlı)
**Zaman:** Cuma akşamı, Bölüm 1'den 1-2 gün sonra
**Durum:** Final (script.js parse edildi, 7 seçim, 3 foto, 10 sessizlik, 140 item). Stil pass'i + büyük harf otomatik geçişi yapıldı.

**Yapı:** 8 sahne (A-H, F yok), 7 seçim, 3 foto (`lena_mirror`, `lena_final`, `zoe_window`).

**Sahne akışı:**
- **A** — Lena hazırlık (3 seçim: elbise, ayakkabı, aksesuar — kıyafet mini-oyunu)
- **B** — Zoe anlatıyor: Marc sabah kahvaltı hazırlamış, çiçek + "günün güzel geçsin" (1 seçim)
- **C** — Lena restorana vardı, erken geldi, Alex gelince sarılma
- **D** — Zoe evde: yemek, kanepe, Marc Sex and the City'i kendisi açtı ("normalde dalga geçer") + battaniye (1 seçim) — `zoe_window` foto
- **E** — Lena tuvaletten paralel anlatım: Alex'in yakın bir kız arkadaşı (finans sektörü) ipucu (1 seçim)
- **G** — Lena dönüşte: iyi geçti + Alex'in "eski bir hikaye" ihtarı (1 seçim)
- **H** — Gece kapanışı, üç kadın iyi hissediyor, sakin "iyi geceler", sonra cliffhanger ("Marc hâlâ kalkmadı bilgisayardan / Tatlıcık / Mutluluğa bak")

**Bu bölümde yerleşen şeyler:**
- Marc'ın bu hafta **aktif tatlılık dozu** (kahvaltı + Sex and the City'i kendisi açtı + battaniye)
- Lena'nın Alex'le ilk buluşması (Cuma gecesi)
- Alex'in **yakın bir kız arkadaşı** + finans sektörü ipucu (Sara için zemin) — *Alex-Marc doğrudan iş ortaklığı YOK, sadece Sara üzerinden bağ var*
- Alex'in "eski bir hikayesi var" — Sara pre-echo (Sahne G)
- Zoe'nin "son günlerimdeki o his gitti sanki" rahatlaması — B1 şüphesini tanıyan self-reference

**Bölüm 3 için zemin:**
- 🌱 **Sahne E Seçim A:** Alex'in çok yakın bir kız arkadaşı + finans sektörü → B3'te Sara adının çıkışına zemin (Alex-Marc iş ortağı bağlantısı KALDIRILDI; sadece Sara üzerinden bağ var)
- 🌱 **Sahne G:** Alex'in eski ilişki hikayesi → Sara'nın Alex'in eski girl best friend'i olduğunun ön sinyali

**Açık sorular (stil pass'inden önce karar):**
- Sahne E Seçim **B yolu** (detay sonra) seçilirse B3 açılışı nasıl? Sara adı finans/firma bilgisi olmadan çıkarsa süreklilik çatlar. **Ya B yolu kaldırılmalı, ya B3 iki versiyonlu açılmalı.**
- Sahne D Seçim B kapanışı "seni özledim biraz sıkıntılı olmayalım bu akşam" → Zoe'nin YOU ile dinamiği. Bilinçli mi, yoksa yumuşatmak mı lazım?
- Sahne H cliffhanger yok — sakin kapanış. Bu bilinçli "fırtına öncesi sessizlik" (B3 Sara name drop) için kabul edilebilir ama engine seviyesinde bir sonraki bölümün iştahını açan bir detay eksik. Belki son mesajdan sonra Marc'tan küçük bir şey? (örn. tuhaf zamanlı "iyi geceler" ekran görüntüsü)

### BÖLÜM 3 — "Sara" 📝

**Dalga:** ↓ AŞAĞI (ilk isim damlaması)

Alex'in konuşmasından Sara'nın adı çıkıyor. Sara:
- Alex'in eski girl best friend'i
- Marc'la aynı şirkette
- Şu sıralar "aynı şirketten biriyle ilgileniyor" (Alex'in sözü)

Lena donuyor, Alex bağlantıyı göremiyor. Stalk başlıyor.

**Ünlü sahne notu (eski notlardan):** "toilet scene" — Lena tuvalete kaçıp Zoe'ye yazıyor mu, yoksa grup içinde mi tutuyor?

### BÖLÜM 4 — "Çok Tatlı" 📝 — KÜÇÜK YANLIŞ ALARM

**Dalga:** ↑ YUKARI

Marc yine aşırı tatlı. Zoe stalk sırasında Marc + Sara'nın bir şirket etkinliğinde yan yana fotoğrafını buluyor. Panik. Sonra ortaya çıkıyor ki partide 20 kişi var, Marc sadece o anda yakalanmış. Zoe rahatlıyor. **Ama hafif bir "yine de..." kalıyor.**

**Wave yapısı:** şüphe kurulur → makul açıklama gelir → rahatlama + suçluluk → artık huzursuzluk

### BÖLÜM 5 — "Fotoğraf" 📝

**Dalga:** ↓ AŞAĞI

Sara'nın Instagram'ında bir fotoğraf — Marc'ın saati arka planda çıkıyor. (Bölüm 1'de bahsedilen hediye saat.) Yani Sara o saati Marc'tan görmüş/giymiş. Büyük ipucu.

### BÖLÜM 6 — "İş Seyahati" 📝

**Dalga:** ↓ AŞAĞI

Marc yeni bir iş seyahati duyuruyor — normal görünüyor. Ama Zoe kontrol ediyor: Sara da aynı şehirde.

### BÖLÜM 7 — "Dönüş" 🔲

**Dalga:** ↑ YUKARI

Marc dönmüş, güzel bir şey getirmiş. Zoe yumuşuyor.
*[Detay çerçeve yok — yazarken düşünmemiz gereken noktalar: hediye ne, Zoe ne kadar yumuşuyor, YOU'nun tepki açısı]*

### BÖLÜM 8-9 — BÜYÜK YANLIŞ ALARM

**Bölüm 8 — "Lena'nın Sorusu"** (↓)
Marc'ın telefonunda "S." ismi görünüyor. Zoe donuyor. Bu sefer **sormayı deniyor.** 

**Bölüm 9 — "Her Şey Yolunda"** (↑ ama zehirli)
Marc üste çıkıyor: "bana güvenmiyor musun, bu ne biçim davranış?" Zoe özür diliyor. "S." aslında iş arkadaşı Serkan çıkıyor. Marc anlayışlı davranmıyor — Zoe'nin suçluluk duygusunu **kullanıyor.** Bu yüzden Zoe bir türlü adım atamıyor.

**Wave yapısı:** ciddi şüphe → ateşli reddetme → gerçek açıklama → Zoe **kendini suçluyor** → Marc suçluluğu silah yapıyor

### BÖLÜM 10 — "Ekran Görüntüsü" 🔲

**Dalga:** ↓ AŞAĞI

Silinmiş bir mesaj preview'ı (WhatsApp bildirim ekranında silinmeden önce görülen snippet). Zoe yakalıyor.

### BÖLÜM 11 — "Sara'nın DM'i" 🔲

**Dalga:** — (düz, gerilim)

**Mekanik:** Sara, YOU'nun oyundaki YOU hesabını Alex üzerinden bulur. Fake hesabı fark etmiş, takip etmiş. YOU'ya DM atar: "Hi, I think we have mutual friends." [?]
YOU'yu test eder. YOU ne kadar açılacağına karar verir.

### BÖLÜM 12 — "Sorma Bana" — DALLANMA ⚡

Zoe YOU'ya direkt soruyor: "biliyor musun bir şey?"

- **Yol A:** YOU anlatıyor → Zoe bilinçli, açık yüzleşme
- **Yol B:** YOU susuyor → Zoe kendisi anlıyor, daha güçlü an

### BÖLÜM 13 — "Son İpucu" — A/B

İki versiyon:
- **13A** (YOU anlattı): Zoe kanıt topluyor, yüzleşmeye hazırlanıyor
- **13B** (YOU sustu): Zoe kendi keşfinin son parçasını buluyor

### BÖLÜM 14 — "Biliyordum" — TEK FİNAL

Her iki yoldan da aynı sona gelir. Zoe ipuçlarından **emin** — sert kanıt yok. Marc'a tek bir şey yazıyor. **Marc'ın cevabını hiç görmüyoruz.** Zoe grup sohbetine tek satır yazıyor. Lena ve YOU okuyor.

---

## İKİ YANLIŞ ALARM — MEKANİK

### KÜÇÜK (Bölüm 4)
- **Kurgu:** Şirket etkinliği fotoğrafı (Marc + Sara yan yana)
- **Çözüm:** 20 kişilik parti, kadraj rastgele
- **Yapı:** şüphe → makul açıklama → rahatlama + hafif suçluluk → artık huzursuzluk

### BÜYÜK (Bölüm 8-9)
- **Kurgu:** Telefonda "S." ismi
- **Çözüm:** İş arkadaşı Serkan (gerçekten)
- **Twist:** Marc anlayışlı davranmıyor — üste çıkıyor, Zoe'yi suçluluk altında bırakıyor
- **Yapı:** ciddi şüphe → sorgulama → ateşli reddetme → gerçek açıklama → Zoe kendini suçluyor → Marc bunu silah yapıyor

### GENEL PRENSİP — HER İPUCUNUN "AMA BELKİ DEĞİL" VERSİYONU VAR

| İpucu | "Ama belki değil..." |
|-------|---------------------|
| Ruj izi (B1) | Ofiste başka kadınlar kahve içmiştir |
| "Neden sordun ki" (B1) | Yorgun, savunmaya geçti |
| İş seyahati hafta sonu (B1) | Şirketi gerçekten öyle çalışıyor |
| Saat (B5) | Sara benzer bir saat almış olabilir |
| İş arkadaşı "S." (B8) | Serkan gerçekten |

Her şüphelendiğinde Marc Zoe'yi suçlu hissettiriyor. Oyuncu da zaman zaman "acaba Zoe paranoyak mı" diyor.

---

## GENEL PRENSİPLER

### ✅ Oturmuş kararlar

1. **Açık iletişim:** Oyuncu karakterleri yeni tanıyor, ima yasak
2. **Seçimler yorum formatında:** Soru değil, tepki/yorum (sonu "?" olmayacak)
3. **Her seçim karakter cevabına bağlanmalı:** Dekoratif değil
4. **Reply zinciri tipolojisi** (stil kılavuzunda detay): taraflı / hakem / tavır değiştirme
5. **Cliffhanger:** Her bölüm sonunda, açık cümle (tek kelime "bak" yasak)
6. **Fotoğraf/selfie:** Her bölümde 3-5 görsel an
7. **5 dakika/bölüm hedefi:** ~80-130 item, ~6-10 seçim
8. **Marc'ın sesi sadece screenshot:** asla grup sohbetine girmez
9. **Mekan ve ilişki mantığı:** aynı evdekiler WhatsApp'ta uzun sohbet etmez
10. **Caption stratejisi:** foto caption mesajın tekrarı değil, sesli düşünce
11. **Sara aktif:** pasif 3. kişi değil, aktif olarak ipucu bırakıyor
12. **Lena'nın arkı:** Zoe ile ayna — kontrol hiç olmayan (Zoe) / hep olmak isteyen (Lena)

### 🟡 Açık sorular

1. **Direkt kanıt vs. sadece şüphe:** Final Zoe sadece ipuçlarından emin olup bitiriyor (plan). Ama yol boyunca oyuncunun gördüğü direkt kanıt var mı? Şu anki plan: **hayır, hiç yok.** Zoe'nin finaldeki gücü tam olarak buradan geliyor — hard proof yok ama emin. Bunu onayla.
2. **Sara'nın DM dili ve tonu** (B11) — ne kadar tehditkâr, ne kadar düzgün?
3. **Bölüm 14 final cümlesi** — Zoe gruba ne yazıyor? Tek satır.

---

## DEĞİŞİKLİK LOG'U

### v0.6 (2026-04-28) — Bölüm 2 final + büyük genel pass
- **Bölüm 1:** Son seçim (00:08) yeniden yazıldı — A: "Marc'la sabah konuş, gözlerine bakarak" + B: "Tanıdığım yüz / ama hiçbir şey anlamıyorum" finali. ~16 nokta düzenleme, 9 özel isim düzeltmesi.
- **Bölüm 2:** Final hali oluştu (143 → 140 item, 7 seçim). Sahne D'de "belgesel" → "Sex and the City" (Marc kendisi açtı). Sahne E'de "iş ortağı" lafı kaldırıldı, Alex'in "yakın bir kız arkadaşı + finans sektörü" zemin koyuldu. Sahne H cliffhanger: "Marc hâlâ kalkmadı bilgisayardan / Tatlıcık / Mutluluğa bak".
- **Karakter bağı düzeltildi:** Alex-Marc *doğrudan iş ortaklığı YOK*, sadece Sara üzerinden bağ var. Bu world_state.json ve episode_notes'a yansıdı.
- **Engine:** Reply chain `_timer`'a alındı (pause-safe). Channel switch fade-out + bg renk değişimi (group ↔ DM). Cache-bust v4.
- **Genel UI:** Status bar (9:41 AM + ikonlar) kaldırıldı. CTA klavye üstüne taşındı. Bölüm 1: "Go to the next episode / Bölüm 2", Bölüm 2: "Coming soon / Bölüm 3".
- **Otomatik geçiş:** Klavye autocapitalize prensibine geçildi — Zoe ve Lena mesajları artık cümle başında büyük harfle başlıyor (398 değişiklik). ALL CAPS, emoji, noktalama, sayı, tırnak içi cümleler korundu. Özel isimler de büyütüldü (Marc, Lena, Zoe, Alex, Sara — 13 yer).

### v0.5 (2026-04-22) — Rebuild
- Dosya önceki chat çökmesinde kayboldu, geçmiş chat'lerden yeniden toplandı.
- Yapı: 15 → 14 bölüm (Bölüm 1 yazılırken eski B2 içeriği buraya sığdı).
- Mevcut durum güncellendi: B1 pass 3 bitti, B2 iskelet var.

### v0.4 (önceki) — kayıp
### v0.3 (önceki) — kayıp
### v0.2 (önceki) — kayıp
### v0.1 — iskelet
